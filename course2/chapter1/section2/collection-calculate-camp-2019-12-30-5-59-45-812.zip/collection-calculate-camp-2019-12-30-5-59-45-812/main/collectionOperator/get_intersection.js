'use strict';

function get_intersection(collection_a, collection_b) {
  //在这里写入代码
  var res;
  var index;
  for (var i = 0, index = 0; i < collection_b.length; i++) {
    if (collection_a.includes(collection_b[i])) {
      res[index] = collection_b[i];
      index++;
    }
  }
  return res;
}

module.exports = get_intersection;
