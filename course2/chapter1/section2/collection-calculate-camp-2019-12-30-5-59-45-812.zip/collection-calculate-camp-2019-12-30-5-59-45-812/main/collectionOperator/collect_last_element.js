'use strict';

function collect_last_element(collection) {
  //在这里写入代码
  return collection[collection.length-1];
}

module.exports = collect_last_element;
