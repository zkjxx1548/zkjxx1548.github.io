'use strict';

function get_letter_interval(number_a, number_b) {
  //在这里写入代码
  const word = [
    'a', 'b', 'c', 'd', 'e', 'f', 'g', 
    'h', 'i', 'j', 'k', 'l', 'm', 'n', 
    'o', 'p', 'q', 'r', 's', 't', 
    'u', 'v', 'w', 'x', 'y', 'z'
  ];
  var res = [];
  var index = 0;
  if (number_a === number_b) {
    return word[number_a - 1];
  }else if (number_a < number_b) {
    for (var i = number_a; i <= number_b; i++) {
      res[index] = get_letter(i);
      index++;
    }
  }else{
    for (var i = number_b; i <= number_a; i--) {
      res[index] = get_letter(i);
      index++;
    }
  }
  return res;

  function get_letter (number) {
    var wordIndex;
    wordIndex= (number-1) % 26;
    return word[wordIndex];
  }
}

module.exports = get_letter_interval;
