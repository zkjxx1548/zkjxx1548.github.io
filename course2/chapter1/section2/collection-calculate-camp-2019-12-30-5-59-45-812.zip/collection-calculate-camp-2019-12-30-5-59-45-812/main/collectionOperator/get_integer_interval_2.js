'use strict';

function get_integer_interval_2(number_a, number_b) {
  //在这里写入代码
  var result;
  if (number_a < number_b) {
    var index = 0;
    for (var i = number_a; i <= number_b; i++) {
      if (i % 2 === 0) {
        result[index] = i;
        index++;
      }
    }
    return result;
  }else if (number_a > number_b) {
    var index = 0;
    for (var i = number_a; i >= number_b; i--) {
      if (i % 2 === 0) {
        result[index] = i;
        index++;
      }
    }
    return result;
  }else{
    if (number_a % 2 === 0) {
      result[0] = number_a;
      return result;
    }else{//相同，且为奇数
      return [];
    }
  }

}

module.exports = get_integer_interval_2;
