'use strict';

function get_integer_interval(number_a, number_b) {
  //在这里写入代码
  var res = [];
  var index;
  if (number_b === number_a) {
    res[0] = number_a;
  } else if (number_a < number_b) {
    index = 0;
    for (var i = number_a; i < number_b + 1; i++) {
      res[index] = i;
      index++;
    }
  } else {
    index = 0;
    for (var i = number_a; i > number_b - 1; i--) {
      res[index] = i;
      index++;
    }
  }
  return res;
}

module.exports = get_integer_interval;

