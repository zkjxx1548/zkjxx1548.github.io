'use strict';

function find_element_last_subscript(collection, element) {
  //在这里写入代码
  return collection.reverse().findIndex(element);
}

module.exports = find_element_last_subscript;
