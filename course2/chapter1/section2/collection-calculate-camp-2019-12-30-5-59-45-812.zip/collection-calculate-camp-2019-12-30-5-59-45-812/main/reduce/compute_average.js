'use strict';

function compute_average(collection) {
  //在这里写入代码
  var sum = collection.reduce(getSum);
  return sum / collection.length;

  function getSum(acc, cur) {
    return acc + cur;
  }
}

module.exports = compute_average;

