'use strict';

function compute_median(collection) {
  //在这里写入代码
  collection.sort();
  var len = collection.length;
  if (len % 2 === 1) {
    return collection[parseInt(len / 2)];
  }else{
    var sum = collection[parseInt(len / 2) - 1] + collection[parseInt(len / 2)];
    return sum / 2;
  }
}

module.exports = compute_median;


