'use strict';

function collect_max_number(collection) {
  //在这里写入代码
  return collection.reduce(getMax);

  function getMax(acc, cur) {
    if (acc > cur) {
      return acc;
    }else{
      return cur;
    }
  }
}

module.exports = collect_max_number;
