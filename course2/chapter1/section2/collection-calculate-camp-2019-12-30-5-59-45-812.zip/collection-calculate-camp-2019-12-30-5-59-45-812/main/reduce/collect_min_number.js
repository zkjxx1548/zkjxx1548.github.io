'use strict';

function collect_min_number(collection) {
  //在这里写入代码
  return collection.reduce(getMin);

  function getMin(acc, cur) {
    if (acc < cur) {
      return acc;
    }else{
      return cur;
    }
  }
}

module.exports = collect_min_number;

