'use strict';

function find_element_first_subscript(collection, element) {
  //在这里写入代码
  return collection.findIndex(element);
}

module.exports = find_element_first_subscript;

