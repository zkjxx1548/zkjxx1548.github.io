'use strict';

function compute_chain_median(collection) {
  //在这里写入代码
}

module.exports = compute_chain_median;
