function create_updated_collection(collection_a, object_b) {
  //在这里写入代码
  var res = [];
  var singleWord = [];
  var index = 0;
  for (var i = 0; i < collection_a.length; i++) {
    if (!singleWord.includes(collection_a[i])) {
      var object_word = {};
      singleWord.push(collection_a[i]);
      object_word["key"] = collection_a[i];
      object_word["count"] = 1;
      res.push(object_word);
    }else{
      index = getWordIndex(singleWord, collection_a[i]);
      res[index].count++;
    }
  }
  var reduceCount = 0;
  for (var i = 0; i < object_b.value.length; i++) {
    for (var j = 0; j < res.length; j++) {
      if (object_b.value[i] === res[j].key) {
        reduceCount = getReduceCount(res[j].count);
        res[j].count -= reduceCount;
      }
    }
  }
  return res;

  function getReduceCount(count) {
    return Math.floor(count / 3);
  }
  
  function getWordIndex(collection, element) {
    for (var i = 0; i < collection.length; i++) {
      if (element === collection[i]) {
        return i;
      }
    }
  }
}

module.exports = create_updated_collection;
