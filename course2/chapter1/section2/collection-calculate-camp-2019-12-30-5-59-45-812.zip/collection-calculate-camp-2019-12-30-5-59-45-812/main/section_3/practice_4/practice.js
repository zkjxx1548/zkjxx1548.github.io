function create_updated_collection(collection_a, object_b) {
  //在这里写入代码
  var res = [];
  var singleWord = [];
  var index = 0;
  var wordCount = 0;
  for (var i = 0; i < collection_a.length; i++) {
    wordCount = getWordCount(collection_a[i]);
    if (!singleWord.includes(collection_a[i][0])) {
      var object_word = {};
      singleWord.push(collection_a[i]);
      object_word["key"] = collection_a[i][0];
      object_word["count"] = wordCount;
      res.push(object_word);
    }else{
      index = getWordIndex(singleWord, collection_a[i]);
      res[index].count += wordCount;
    }
  }
  var reduceCount = 0;
  for (var i = 0; i < object_b.value.length; i++) {
    for (var j = 0; j < res.length; j++) {
      if (object_b.value[i] === res[j].key) {
        reduceCount = getReduceCount(res[j].count);
        res[j].count -= reduceCount;
      }
    }
  }
  return res;

  function getWordIndex(collection, element) {
    for (var i = 0; i < collection.length; i++) {
      if (element === collection[i]) {
        return i;
      }
    }
  }

  function getWordCount(element) {
    if (element.length !== 1) {
      return parseInt(element.slice(2));
    }else{
      return 1;
    }
  }

  function getReduceCount(count) {
    return Math.floor(count / 3);
  }
}

module.exports = create_updated_collection;
