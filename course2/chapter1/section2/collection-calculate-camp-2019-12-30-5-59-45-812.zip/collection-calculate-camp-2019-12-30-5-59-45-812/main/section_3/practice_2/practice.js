function create_updated_collection(collection_a, object_b) {
  //在这里写入代码
  var reduceCount = 0;
  for (var i = 0; i < object_b.value.length; i++) {
    for (var j = 0; j < collection_a.length; j++) {
      if (object_b.value[i] === collection_a[j].key) {
        reduceCount = getReduceCount(collection_a[j].count);
        collection_a[j].count -= reduceCount;
      }
    }
  }
  return collection_a;

  function getReduceCount(count) {
    return Math.floor(count / 3);
  }
}

  


module.exports = create_updated_collection;
