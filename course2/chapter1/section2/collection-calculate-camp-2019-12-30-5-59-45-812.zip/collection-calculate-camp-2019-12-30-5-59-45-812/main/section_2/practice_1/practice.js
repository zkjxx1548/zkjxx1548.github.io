function count_same_elements(collection) {
  //在这里写入代码
  var res = [];
  var singleWord = [];
  var index = 0;
  for (var i = 0; i < collection.length; i++) {
    if (!singleWord.includes(collection[i])) {
      var object_word = {};
      singleWord.push(collection[i]);
      object_word["key"] = collection[i];
      object_word["count"] = 1;
      res.push(object_word);
    }else{
      index = getWordIndex(singleWord, collection[i]);
      res[index].count++;
    }
  }
  return res;

  function getWordIndex(collection, element) {
    for (var i = 0; i < collection.length; i++) {
      if (element === collection[i]) {
        return i;
      }
    }
  }
}

module.exports = count_same_elements;
