function count_same_elements(collection) {
  //在这里写入代码
  var res = [];
  var singleWord = [];
  var index = 0;
  var wordCount = 0;
  for (var i = 0; i < collection.length; i++) {
    wordCount = getWordCount(collection[i]);
    if (!singleWord.includes(collection[i][0])) {
      var object_word = {};
      singleWord.push(collection[i]);
      object_word["key"] = collection[i][0];
      object_word["count"] = wordCount;
      res.push(object_word);
    }else{
      index = getWordIndex(singleWord, collection[i]);
      res[index].count += wordCount;
    }
  }
  return res;

  function getWordIndex(collection, element) {
    for (var i = 0; i < collection.length; i++) {
      if (element === collection[i]) {
        return i;
      }
    }
  }

  function getWordCount(element) {
    if (element.length !== 1) {
      return parseInt(element.slice(2));
    }else{
      return 1;
    }
  }
}

module.exports = count_same_elements;
