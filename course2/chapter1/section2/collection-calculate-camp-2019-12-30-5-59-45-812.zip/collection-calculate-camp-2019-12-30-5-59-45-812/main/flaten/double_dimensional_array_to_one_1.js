'use strict';

function double_to_one(collection) {

  //在这里写入代码
  var res = [];
  for (var i = 0; i < collection.length; i++) {
    res = res.concat(collection[i]);
  }
  return res;
}

module.exports = double_to_one;
