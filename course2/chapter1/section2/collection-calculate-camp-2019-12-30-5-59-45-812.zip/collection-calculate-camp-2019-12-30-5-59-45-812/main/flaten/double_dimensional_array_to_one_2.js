'use strict';

function double_to_one(collection) {

  //在这里写入代码
  var res = [];
  var togather = [];
  var index = 0;
  for (var i = 0; i < collection.length; i++) {
    togather = togather.concat(collection[i]);
  }
  for (var i = 0; i < togather.length; i++) {
    if (!res.includes(togather[i])) {
      res[index] = togather[i];
      index++;
    }
  }
  return res;
}

module.exports = double_to_one;
