'use strict';

function choose_no_repeat_number(collection) {

  //在这里写入代码
  var res = [];
  for (var i = 0; i < collection.length; i++) {
    if (!res.includes(collection[i])) {
      res.push(collection[i]);
    }
  }
  return res;
}

module.exports = choose_no_repeat_number;
