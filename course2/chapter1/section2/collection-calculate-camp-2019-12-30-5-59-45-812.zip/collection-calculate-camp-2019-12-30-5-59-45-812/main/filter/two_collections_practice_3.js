'use strict';

function choose_divisible_integer(collection_a, collection_b) {

  //在这里写入代码
  var res = [];
  var index = 0;
  for (var i = 0; i < collection_a.length; i++) {
    for (var j = 0; i < collection_b.length; j++) {
      if (collection_a[i] % collection_b[j] === 0) {
        res[index] = collection_a[i];
        index++;
        break;
      }
    }
  }
  return res;
}

module.exports = choose_divisible_integer;
