'use strict';

function choose_common_elements(collection_a, collection_b) {

  //在这里写入代码
  var res;
  var index;
  for (var i = 0, index = 0; i < collection_a.length; i++) {
    if (collection_b.includes(collection_a[i])) {
      res[index] = collection_a[i];
      index++;
    }
  }
  return res;
}

module.exports = choose_common_elements;
