'use strict';

function grouping_count(collection) {

  //在这里写入代码
  var res = {};
  var noRepeat = [];
  for (var i = 0; i < collection.length; i++) {
    if (!noRepeat.includes(collection[i])) {
      noRepeat.push(collection[i]);
      res[collection[i]] = 1;
    }else{
      res[collection[i]] = res[collection[i]] + 1;
    }
  }
  return res;
}

module.exports = grouping_count;
