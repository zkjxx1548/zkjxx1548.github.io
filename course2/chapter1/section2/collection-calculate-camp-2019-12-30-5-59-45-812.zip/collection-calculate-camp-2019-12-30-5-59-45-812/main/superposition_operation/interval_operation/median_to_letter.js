'use strict';

function median_to_letter(collection) {

  //在这里写入代码
  const word = [
    'a', 'b', 'c', 'd', 'e', 'f', 'g', 
    'h', 'i', 'j', 'k', 'l', 'm', 'n', 
    'o', 'p', 'q', 'r', 's', 't', 
    'u', 'v', 'w', 'x', 'y', 'z'
  ];
  var median = getMedianNum(collection);
  return get_letter(median);
  

  function getMedianNum(collection) {
    collection.sort();
    var index = Math.floor(collection.length / 2);
    if (collection.length % 2 === 0) {
      var sum = collection[index - 1] + collection[index];
      return Math.ceil(sum / 2);
    }else{
      return collection[index];
    }
  }

  function get_letter (number) {
    var first = parseInt((number-1) / 26);
    var second = (number-1) % 26;
    if (first === 0) {
      return word[second];
    }else{
      return word[first-1] + word[second];
    }
  }
}

module.exports = median_to_letter;
