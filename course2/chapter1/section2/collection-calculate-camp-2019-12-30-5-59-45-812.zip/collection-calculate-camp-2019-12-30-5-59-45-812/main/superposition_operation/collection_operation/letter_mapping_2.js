'use strict';

function average_to_letter(collection) {

  //在这里写入代码
  var res = [];
  var sum = 0;
  const word = [
    'a', 'b', 'c', 'd', 'e', 'f', 'g', 
    'h', 'i', 'j', 'k', 'l', 'm', 'n', 
    'o', 'p', 'q', 'r', 's', 't', 
    'u', 'v', 'w', 'x', 'y', 'z'
  ];
  for (var i = 0; i < collection.length; i++) {
    sum += collection[i]; 
  }
  var average = Math.ceil(sum / collection.length);
  return get_letter(average);

  function get_letter(number) {
    var wordIndex;
    wordIndex= (number-1) % 26;
    return word[wordIndex];
  }
}

module.exports = average_to_letter;

