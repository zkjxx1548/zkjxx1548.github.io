'use strict';

function even_to_letter(collection) {

  //在这里写入代码
  var res = [];
  const word = [
    'a', 'b', 'c', 'd', 'e', 'f', 'g', 
    'h', 'i', 'j', 'k', 'l', 'm', 'n', 
    'o', 'p', 'q', 'r', 's', 't', 
    'u', 'v', 'w', 'x', 'y', 'z'
  ];
  for (var i = 0; i < collection.length; i++) {
    if (collection[i] % 2 === 0) {
      res.push(get_letter(collection[i]));
    }    
  }
  return res;

  function get_letter (number) {
    var wordIndex;
    wordIndex= (number-1) % 26;
    return word[wordIndex];
  }
}

module.exports = even_to_letter;
