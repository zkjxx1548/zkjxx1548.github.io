'use strict';
var single_element = function(collection){
  var res = [];
  var repeat = [];
  var ress = [];
  for (var i = 1; i < collection.length; i += 2) {
    if(!res.includes(collection[i])) {
      res.push(collection[i]);
    }else if (!repeat.includes(collection[i])){
      repeat.push(collection[i]);
    }
  }
  for (var i = 0; i < res.length; i++) {
    if (!repeat.includes(res[i])) {
      ress.push(res[i]);
    }
  }
  return ress;
};
module.exports = single_element;
