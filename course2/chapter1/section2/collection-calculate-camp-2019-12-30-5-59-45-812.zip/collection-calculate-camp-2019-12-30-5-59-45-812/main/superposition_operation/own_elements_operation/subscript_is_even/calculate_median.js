'use strict';
var calculate_median = function(collection){
  var oddNum = [];
  var medianIndex = 0;
  for (var i = 1; i < collection.length; i += 2) {
    oddNum.push(collection[i]);
  }
  oddNum.sort();
  medianIndex = Math.floor(oddNum.length / 2);
  if (oddNum.length % 2 === 0) {
    var sum = oddNum[medianIndex - 1] + oddNum[medianIndex];
    return sum / 2;
  }else{
    return oddNum[medianIndex];
  }
};
module.exports = calculate_median;
