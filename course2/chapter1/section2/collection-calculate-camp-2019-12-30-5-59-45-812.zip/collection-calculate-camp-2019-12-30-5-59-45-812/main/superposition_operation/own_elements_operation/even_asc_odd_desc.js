'use strict';
var even_asc_odd_desc = function(collection){
  var odd = [];
  var even = [];
  for (var i = 0; i < collection.length; i++) {
    if (collection[i] % 2 === 0) {
      even.push(collection[i]);
    }else{
      odd.push(collection[i]);
    }
  }
  odd.sort(function (a, b) {
    return b - a;
  })
  even.sort(function (a, b) {
    return a - b;
  })
  return even.concat(odd);
};
module.exports = even_asc_odd_desc;
