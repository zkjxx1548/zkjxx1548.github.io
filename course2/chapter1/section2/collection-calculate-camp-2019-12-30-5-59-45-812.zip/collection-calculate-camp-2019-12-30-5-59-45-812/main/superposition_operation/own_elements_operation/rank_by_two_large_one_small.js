'use strict';
function rank_by_two_large_one_small(collection){
  //这里写代码。。。
  collection.sort(function (a, b) {
    return a - b;
  });
  var times = Math.floor(collection.length / 3);
  var number = 0;
  var minIndex = 0;
  for (var i = 0; i < times; i++) {
    minIndex = i * 3;
    number = collection[minIndex];
    collection[minIndex] = collection[minIndex + 1];
    collection[minIndex + 1] = collection[minIndex + 2];
    collection[minIndex + 2] = number;
  }
  return collection;
}
module.exports = rank_by_two_large_one_small;
