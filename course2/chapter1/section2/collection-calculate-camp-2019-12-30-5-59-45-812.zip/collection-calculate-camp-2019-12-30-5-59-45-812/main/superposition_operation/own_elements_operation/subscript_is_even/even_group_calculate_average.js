'use strict';
var even_group_calculate_average = function(collection){
  var eventhOfEven = [];
  var res = [];  
  for (var i = 1; i < collection.length; i+=2) {
    if (collection[i] % 2 === 0) {
      eventhOfEven.push(collection[i]);
    }
  }
  console.log(eventhOfEven)
  if (eventhOfEven.length === 0) {
    res.push(0);
    return res;
  }
  eventhOfEven.sort(function (a, b) {
    return a - b;
  });
  console.log(eventhOfEven)
  var sum = 0;
  var count = 0;
  var numSize = getNumberDigits(eventhOfEven[0]);
  for (var i = 0; i < eventhOfEven.length; i++) {
    if (getNumberDigits(eventhOfEven[i]) === numSize) {
      sum += eventhOfEven[i];
      count++;
    }else{
      res.push(sum / count);
      sum = eventhOfEven[i];
      count = 1;
      numSize = getNumberDigits(eventhOfEven[i]);
    }
  }
  res.push(sum / count);
  return res;
  
  function getNumberDigits(number) {
    var digits = 1;
    while (number >= 10) {
      number /= 10;
      number = Math.floor(number);
      digits++;
    }
    return digits;
  }
};
module.exports = even_group_calculate_average;
