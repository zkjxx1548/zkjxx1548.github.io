'use strict';
function one_add_next_multiply_three(collection){
  var res = [];
  var newNum = 0;
  for (var i = 0; i < collection.length-1; i++) {
    newNum = (collection[i] + collection[i+1]) * 3;
    res.push(newNum);
  }
  return res;
}
module.exports = one_add_next_multiply_three;
