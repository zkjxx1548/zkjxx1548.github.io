'use strict';

function spilt_to_zero(number, interval) {
  //在这里写入代码
  var res = [number];
  var resValue = number;
  while (resValue > 0) {
    resValue = parseFloat((resValue - interval).toFixed(1));
    res.push(resValue);
  }
  return res;
}

module.exports = spilt_to_zero;
