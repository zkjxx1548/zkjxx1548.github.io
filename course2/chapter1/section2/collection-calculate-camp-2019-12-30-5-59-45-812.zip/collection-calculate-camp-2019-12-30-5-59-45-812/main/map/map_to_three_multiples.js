'use strict';
var map_to_three_multiples = function(collections){
  var res = [];
  for (var i = 0; i < collection.length; i++) {
    res.push(collection[i] * 3);
  }
  return res;
};

module.exports = map_to_three_multiples;
