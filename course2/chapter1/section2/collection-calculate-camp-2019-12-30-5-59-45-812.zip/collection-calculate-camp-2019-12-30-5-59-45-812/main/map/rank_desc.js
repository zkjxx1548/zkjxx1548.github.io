'use strict';
var rank_desc = function(collection){
  return collection.sort();
};

module.exports = rank_desc;
