'use strict';
var number_map_to_word_over_26 = function(collection){
  res = [];
  var first;
  var second;
  const word = [
    'a', 'b', 'c', 'd', 'e', 'f', 'g', 
    'h', 'i', 'j', 'k', 'l', 'm', 'n', 
    'o', 'p', 'q', 'r', 's', 't', 
    'u', 'v', 'w', 'x', 'y', 'z'
  ];
  for (var i = 0; i < collection.length; i++) {
    res.push(get_letter(collection[i]));
  }
  return res;

  function get_letter (number) {
    first = parseInt((number-1) / 26);
    second = (number-1) % 26;
    if (first === 0) {
      return word[second];
    }else{
      return word[first-1] + word[second];
    }
  }
};

module.exports = number_map_to_word_over_26;
