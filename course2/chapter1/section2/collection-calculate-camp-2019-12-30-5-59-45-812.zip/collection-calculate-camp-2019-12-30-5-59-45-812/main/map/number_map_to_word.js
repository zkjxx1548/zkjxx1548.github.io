'use strict';
var number_map_to_word = function(collection){
  res = [];
  var wordIndex;
  const word = [
    'a', 'b', 'c', 'd', 'e', 'f', 'g', 
    'h', 'i', 'j', 'k', 'l', 'm', 'n', 
    'o', 'p', 'q', 'r', 's', 't', 
    'u', 'v', 'w', 'x', 'y', 'z'
  ];
  for (var i = 0; i < collection.length; i++) {
    res.push(get_letter(collection[i]));
  }
  return res;

  function get_letter (number) {
    wordIndex = (number-1) % 26;
    return word[wordIndex];
  }
};

module.exports = number_map_to_word;
