# JS进阶集合练习

## 使用简介

1.运行所有测试
```
npm test
```
2.运行某个文件夹下的测试
```
npm run test-single specs/filter/
```
3.运行单个文件的测试
```
npm run test-single specs/filter/choose_even_spec.js
```