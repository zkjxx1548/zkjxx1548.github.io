function bestCharge(selectedItems) {
  let originalPrice = 0;
  let reducePrice = 0;
  const allItems = loadAllItems();
  const promotions = loadPromotions(); 
  let full30Reduce = 0;
  let halfPriceReduce = 0;
  let halfPriceName = "";
  let res = `============= 订餐明细 =============\n`;
  //订餐商品清单模块
  for (let i = 0; i < selectedItems.length; i++) {
    let itemId = selectedItems[i].slice(0, 8);
    let itemCount = parseInt(selectedItems[i].slice(11));
    let itemSubtotal = 0;
    //匹配商品表
    for (let j = 0; j < allItems.length; j++) {
      if (itemId === allItems[j].id) {
        itemSubtotal = allItems[j].price * itemCount;
        originalPrice += itemSubtotal;
        res += allItems[j].name + ` x ` + itemCount + ` = ` + itemSubtotal + `元\n`;
        //半价折扣,更新半价商品名字
        if (promotions[1].items.includes(itemId)) {
          //如果半价的商品不止一个，加逗号
          if (halfPriceName.length > 0) {
            halfPriceName += `，`;
          }
          halfPriceReduce += itemSubtotal / 2;
          halfPriceName += allItems[j].name;
        }
        break;
      }
    }
  }
  res += `-----------------------------------\n`;
  //满减
  full30Reduce = Math.floor(originalPrice / 30) * 6;

  //找到最优惠方案模块
  if (full30Reduce !== 0 || halfPriceReduce !== 0) {
    res += `使用优惠:\n`;
    if (full30Reduce >= halfPriceReduce) {
      res += promotions[0].type + `，省` + full30Reduce + `元\n`;
    }else{
      res += promotions[1].type + `(` + halfPriceName + `)，省` + halfPriceReduce + `元\n`;
    }
    res += `-----------------------------------\n`;
  }
  
  //总计模块
  reducePrice = originalPrice - Math.max(full30Reduce, halfPriceReduce);
  res += `总计：` + reducePrice + `元\n`;

  res += `===================================`;
  return res;
}
